<?php $__env->startSection('content'); ?>

        <!-- BEGIN: Hero Banner Start -->
        <section class="pageBanner" style="background-image: url(<?php echo e(asset('public/ui/assets/images/bg/banner.jpg')); ?>);">
            <div class="overlay"></div>
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <h2 class="bannerTitle">Result</h2>
                        <div class="breadcrumbs"><a href="<?php echo e(route('/')); ?>">Home</a><span>/</span>Result</div>
                    </div>
                </div>
            </div>
        </section>
        <!-- END: Hero Banner End -->

       <!-- BEGIN: About Section Start -->
    <section class="my-5">
        <div class="container">
            <div class="row">

                <div class="col-12">
                    <!-- About Content -->
                    <div class="aboutContent02 ">
                        <h4 class="subTitle mb-3">Results</h4>
                        
                        <p style="text-align: justify;">
                            <?php echo cms_setting_data('results_text'); ?>

                        </p>


                    </div>
                    <!-- About Content -->
                </div>
				
				     <div class="col-lg-12 col-md-12">
                        <aside class="galleryWidget">
                            <h3 class="widgetTitle text-dark">Images</h3>
                            <div class="galleryShots clearfix">
                                <div class="row">
                                    <?php $__currentLoopData = getDataFun('photo_galleries',''); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    
                                    <?php if($row_data->gallery_type == 'result' ): ?>

                                    <div class="col-md-3">

                                        <a class="popup_img float-start" href="<?php echo e(url('/storage/app/'.$row_data->image)); ?>" style="width: 100% ;height:200px;"><img src="<?php echo e(url('/storage/app/'.$row_data->image)); ?>" alt=""></a>
                                    </div>
                                    <?php endif; ?>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </div>

                            </div>
                        </aside>
                    </div>
            </div>
        </div>
    </section>
    <!-- END: About Section End -->

       <?php $__env->stopSection(); ?>


<?php echo $__env->make('ui.layout.headerfooter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/knowledgekingdom.in/httpdocs/resources/views/ui/result.blade.php ENDPATH**/ ?>