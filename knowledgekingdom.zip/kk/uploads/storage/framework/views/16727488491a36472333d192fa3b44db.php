

<!DOCTYPE html>
<html class="no-js" lang="en">

<!-- Mirrored from  /index3.html by  , Mon,   12:46:07 GMT -->
<head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title> <?php echo $__env->yieldContent('page_title'); ?> || <?php echo e(bussiness_setting_data('site_name')); ?></title>

    <meta name="description" content="<?php echo $__env->yieldContent('meta_descripation'); ?>">
    <meta name="keywords" content="<?php echo $__env->yieldContent('meta_keyword'); ?>">
    <meta name="author" content="Satyakabir E-solutions Private Limited">

        <!-- BEGIN: CSS -->
        <link rel="stylesheet" href="<?php echo e(asset('public/ui/assets/css/bootstrap.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('public/ui/assets/css/animate.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('public/ui/assets/css/fontawesome-all.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('public/ui/assets/css/flaticon.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('public/ui/assets/css/owl.theme.default.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('public/ui/assets/css/owl.carousel.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('public/ui/assets/css/lightcase.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('public/ui/assets/css/nice-select.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('public/ui/assets/css/main.css')); ?>">
        <!-- END: CSS -->

        <!-- BEGIN: Favicon -->
        <link rel="icon"  type="image/png" href="<?php echo e(url('/storage/app/'.bussiness_setting_data('favicon'))); ?>">
        <!-- END: Favicon -->
    </head>
    <style>
        .pagination{
            /* color: red */
            --bs-pagination-color: var(--primay-color) !important;
            --bs-pagination-hover-color: var(--primay-color) !important;
            --bs-pagination-active-border-color: #dc3545;
        }
        .active > .page-link {
            background-color: var(--primay-color) !important;
        }
    </style>
    <body>
        <!-- BEGIN: PreLoder Section -->
        <section class="preloader" id="preloader">
            <button class="closeLoader immiPressBtn"><span>Cancel Preloader</span></button>
            <div class="spinner-eff spinner-eff-1">
                <div class="bar bar-top"></div>
                <div class="bar bar-right"></div>
                <div class="bar bar-bottom"></div>
                <div class="bar bar-left"></div>
            </div>
        </section>
        <!-- END: PreLoder Section -->

        <!-- BEGIN: Header Section -->
        <header class="header03 isSticky">
            <svg fill="#233152" width="380" height="99" viewBox="0 0 380 99"  xmlns="http://www.w3.org/2000/svg"><path d="M380 -1H0V99H313.587L380 -1Z"/></svg>
            <svg class="last" fill="#233152" width="380" height="99" viewBox="0 0 380 99"  xmlns="http://www.w3.org/2000/svg"><path d="M380 -1H0V99H313.587L380 -1Z"/></svg>
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="header01Inner">
                            <!-- Logo -->
                            <div class="logo01">
                                <a href="<?php echo e(route('/')); ?>"><img src="<?php echo e(url('/storage/app/'.bussiness_setting_data('logo'))); ?>" alt="ImmiPress"/></a>
                            </div>
                            <!-- Logo -->
                            <!-- Nav Menu -->
                            <a href="javascript:void(0)" class="menuBtn mbText"><i class="fa-solid fa-bars"></i><span>Menu</span></a>
                            <nav class="mainMenu">
                                <ul class="sub-menu">
                                    <li class="">
                                        <a href="<?php echo e(route('/')); ?>">Home</a>

                                    </li>
                                    <li class="menu-item-has-children">
                                        <a href="javascript:void(0);">About Us</a>
                                        <ul class="sub-menu">
                                            <li><a href="<?php echo e(route('introduction-page')); ?>" class="text-dark">Introduction</a></li>
                                            <li><a href="<?php echo e(route('our-team-page')); ?>" class="text-dark">Our Team</a></li>
                                            <li><a href="<?php echo e(route('why-us-page')); ?>" class="text-dark">Why Us</a></li>
                                        </ul>
                                    </li>
                                    <li class="menu-item-has-children">
                                        <a href="javascript:void(0);">Countries</a>
                                        <ul class="sub-menu">
                                            <?php $__currentLoopData = getDataFun('countries',''); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                            <li><a href="<?php echo e(route('country-details-page',$country_data->slug)); ?>" class="text-dark"> <?php echo e($country_data->title); ?></a></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </ul>
                                    </li>
                                    <li class="menu-item-has-children">
                                        <a href="javascript:void(0);">Coaching</a>
                                        <ul class="sub-menu">
                                            <?php $__currentLoopData = getDataFun('coachings',''); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coachings_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><a href="<?php echo e(route('coaching-details-page',$coachings_data->slug)); ?>" class="text-dark"><?php echo e($coachings_data->title); ?> </a></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </ul>
                                    </li>
                                    <li class="">
                                        <a href="<?php echo e(route('testimonial-page')); ?>">Testimonial</a>

                                    </li>
                                    <li class="">
                                        <a href="<?php echo e(route('achievers-page')); ?>">Achievers</a>

                                    </li>
                                    <li class="">
                                        <a href="<?php echo e(route('blog-page')); ?>">Blog</a>

                                    </li>
                                    <li class="">
                                        <a href="<?php echo e(route('contact-page')); ?>">Contact Us</a>

                                    </li>
                                    
                                </ul>
                            </nav>
                            <!-- Nav Menu -->

                            <!-- Popup Btn -->
                            <a class="popupBtn" href="javascript:void(0);">
                                <svg fill="#E94D4E" width="24" height="16" viewBox="0 0 24 16"  xmlns="http://www.w3.org/2000/svg"><path d="M0.75 15.5V13H23.25V15.5H0.75ZM0.75 9.25V6.75H23.25V9.25H0.75ZM0.75 3V0.5H23.25V3H0.75Z"/></svg>
                            </a>
                            <!-- Popup Btn -->
                        </div>
                    </div>
                </div>
            </div>
        </header>
        <div class="blanks"></div>
        <!-- END: Header Section -->
         <!-- BEGIN: Popup Sidebar Widget -->
    <section class="popupSidebarSsec">
        <div class="popupSidebarOverlay"></div>
        <div class="widgetArea">
            <a href="javascript:void(0);" class="widgetCloser"><i class="fa-solid fa-xmark"></i></a>
            <div class="aboutWidgetArea">
                <div class="wdLogo">
                    <a href="<?php echo e(url('/')); ?>"><img src="<?php echo e(url('/storage/app/'.bussiness_setting_data('logo'))); ?>" alt="ImmiPress"></a>
                </div>
               
                <p>
                    We take a bottom-line approach to each project. Our clients consistently see increased traffic, enhanced
                    brand loyalty and new leads thanks to our work.
                </p>
                <h3>Contact info</h3>
                <div class="iconBox01">
                    <div class="ibBox"><i class="flaticon-phone-call"></i></div>
                    <h3 class="ibTitle">Call Us</h3>
                    <p><a href="tel:<?php echo e(bussiness_setting_data('phone_1')); ?>"><?php echo e(bussiness_setting_data('phone_1')); ?></a></p>
                </div>
                <div class="iconBox01">
                    <div class="ibBox"><i class="flaticon-email"></i></div>
                    <h3 class="ibTitle">Email us</h3>
                    <p><a href="mailto:<?php echo e(bussiness_setting_data('email_1')); ?>"><?php echo e(bussiness_setting_data('email_1')); ?></a></p>
                </div>
                <div class="iconBox01">
                    <div class="ibBox"><i class="flaticon-placeholder"></i></div>
                    <h3 class="ibTitle">Address</h3>
                    <p><a href="<?php echo e(bussiness_setting_data('map')); ?>"><?php echo e(bussiness_setting_data('address')); ?></a></p>
                </div>
                <div class="socialItem">
                    <a href="<?php echo e(bussiness_setting_data('facebook')); ?>"><i class="fa-brands fa-facebook-f"></i></a>
                    <a href="<?php echo e(bussiness_setting_data('instagram')); ?>"><i class="fa-brands fa-instagram"></i></a>
                    <a href="<?php echo e(bussiness_setting_data('linkedin')); ?>"><i class="fa-brands fa-linkedin-in"></i></a>
                    <a href="<?php echo e(bussiness_setting_data('twitter')); ?>"><i class="fa-brands fa-twitter"></i></a>
                </div>
                <iframe
                    src="<?php echo e(bussiness_setting_data('map')); ?>"
                    allowfullscreen></iframe>
            </div>
        </div>
    </section>
    <!-- END: Popup Sidebar Widget -->

          <?php echo $__env->yieldContent('content'); ?>


		
		
                     <!-- BEGIN: Footer Start -->
        <footer class="footer_02"  style="background-image: url(assets/images/bg/4.png);">
            <div class="container">
                <div class="row">
                    <!-- About Widget -->
                    <div class="col-lg-3 col-md-5">
                        <aside class="aboutWidget">
                            <a href="<?php echo e(route('/')); ?>"><img src="<?php echo e(url('/storage/app/'.bussiness_setting_data('logo'))); ?>" alt="<?php echo e(bussiness_setting_data('site_name')); ?>"></a>
                            <p><?php echo e(Str::substr(cms_setting_data('about_home'), 0, 200)); ?></p>
                            <div class="abSocial">
                                <a href="<?php echo e(bussiness_setting_data('facebook')); ?>"><i class="fa-brands fa-facebook-f"></i></a>
                                <a href="<?php echo e(bussiness_setting_data('twitter')); ?>"><i class="fa-brands fa-twitter"></i></a>
                                <a href="<?php echo e(bussiness_setting_data('instagram')); ?>"><i class="fa-brands fa-instagram"></i></a>
                                <a href="<?php echo e(bussiness_setting_data('linkedin')); ?>"><i class="fa-brands fa-linkedin"></i></a>
                            </div>
                        </aside>
                    </div>
                    <!-- About Widget -->
                    <!-- Service Widget -->
                    <div class="col-lg-3 col-md-7">
                        <aside class="widget serviceMenu">
                            <h3 class="widgetTitle">USEFUL LINKS</h3>
                            <ul class="menu">
                                
                                <li><a href="<?php echo e(route('introduction-page')); ?>">About Us</a></li>
                                <li><a href="<?php echo e(route('contact-page')); ?>">Contact Us</a></li>
                                <li><a href="<?php echo e(route('result-page')); ?>">Results</a></li>
                                <li><a href="<?php echo e(route('scholarship-page')); ?>">Scholarship</a></li>
								 <li><a href="<?php echo e(route('press-release-page')); ?>">Press Release</a></li>
								
                                <li><a href="<?php echo e(route('faq')); ?>">Faq</a></li>

                            </ul>
                        </aside>
                    </div>
                    <!-- Service Widget -->
                    <!-- Contact Widget -->
                    <div class="col-lg-3 col-md-6">
                        <aside class="contactWidget">
                            <h3 class="widgetTitle">Get in touch</h3>
                            <div class="iconBox01">
                                <div class="ibBox"><i class="flaticon-placeholder"></i></div>
                                <h3 class="ibTitle">Address</h3>
                                <p><?php echo e(bussiness_setting_data('address')); ?></p>
                            </div>
                            <div class="iconBox01">
                                <div class="ibBox"><i class="flaticon-phone-call"></i></div>
                                <h3 class="ibTitle">Phone</h3>
                                <p><?php echo e(bussiness_setting_data('phone_1')); ?></p>
                            </div>
                            <div class="iconBox01">
                                <div class="ibBox"><i class="flaticon-email-1"></i></div>
                                <h3 class="ibTitle">Email</h3>
                                <p><?php echo e(bussiness_setting_data('email_1')); ?></p>
                            </div>
                        </aside>
                    </div>
                    <!-- Contact Widget -->
                    <!-- Newsletter Widget -->
                    <div class="col-lg-3 col-md-6">
                        <aside class="galleryWidget">
                            <h3 class="widgetTitle">Countries</h3>
                            <div class="galleryShots clearfix">
                                <?php $__currentLoopData = getDataFun('countries','6'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a class=" float-start" href="<?php echo e(route('country-details-page',$country_data->slug)); ?>"><img src="<?php echo e(url('/storage/app/'.$country_data->logo)); ?>" alt="<?php echo e($country_data->title); ?>"></a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                            </div>
                        </aside>
                    </div>
                    <!-- Newsletter Widget -->
                </div>
            </div>
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12"><div class="brhr"></div></div>
                </div>
            </div>
            <div class="container">
                <div class="row">
                    <div class="col-md-8">
                        <p class="copyright">Copyright 2023 by <a href="https://satyakabir.com" target="_blank" class="footer-link fw-bolder">Satya Kabir E-solutions Private Limited</a> All Right Reserved.</p>
                    </div>

                </div>
            </div>

        </footer>
        <!-- END: Footer End -->
    <!-- Bact To Top -->
    <a href="javascript:void(0);" id="backtotop"><i class="fa-solid fa-arrow-up"></i></a>
    <!-- Bact To Top -->

    <!-- BEGIN: JS -->
    <script src="<?php echo e(asset('public/ui/assets/js/jquery.js')); ?>"></script>
    <script src="<?php echo e(asset('public/ui/assets/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('public/ui/assets/js/owl.carousel.min.js')); ?>"></script>
    <script src="<?php echo e(asset('public/ui/assets/js/jquery.appear.js')); ?>"></script>
    <script src="<?php echo e(asset('public/ui/assets/js/lightcase.js')); ?>"></script>
    <script src="<?php echo e(asset('public/ui/assets/js/jquery.nice-select.js')); ?>"></script>
    <script src="<?php echo e(asset('public/ui/assets/js/jquery.plugin.min.js')); ?>"></script>
    <script src="<?php echo e(asset('public/ui/assets/js/jquery.countdown.min.js')); ?>"></script>

    <!-- Custome Js -->
    <script src="<?php echo e(asset('public/ui/assets/js/theme.js')); ?>"></script>
    <!-- END: JS -->

    <!--Modal JS Script -->
    <script type="text/javascript">
        $(window).load(function() {
            $('#onload').modal('show');
        });
    </script>
		
<script type="text/javascript">
    (function() {
        var options = {
             
             //call: " +447540350841", // calling Number
            whatsapp: "+919893484938&text= I'm Interested", // WhatsApp number
            //facebook: "103743984353168", // Facebook page ID
            call_to_action: "Hi! I'm here to help you.", // Call to action
            button_color: "#180009", // Color of button
            position: "left", // Position may be 'right' or 'left'
            order: "call,facebook,whatsapp", // Order of buttons
        };
        var proto = document.location.protocol,
            host = "getbutton.io",
            url = proto + "//static." + host;
        var s = document.createElement('script');
        s.type = 'text/javascript';
        s.async = true;
        s.src = url + '/widget-send-button/js/init.js';
        s.onload = function() {
            WhWidgetSendButton.init(host, proto, options);
        };
        var x = document.getElementsByTagName('script')[0];
        x.parentNode.insertBefore(s, x);
    })();
</script>		
		
<!--Start of Tawk.to Script-->
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/652391b66fcfe87d54b7d24f/1hc9f2h3l';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script-->
</body>


</html>
<?php /**PATH /var/www/vhosts/knowledgekingdom.in/httpdocs/resources/views/ui/layout/headerfooter.blade.php ENDPATH**/ ?>