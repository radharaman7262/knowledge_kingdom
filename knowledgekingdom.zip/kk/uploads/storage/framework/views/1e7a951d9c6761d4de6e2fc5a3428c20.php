<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH /var/www/vhosts/knowledgekingdom.in/httpdocs/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/button.blade.php ENDPATH**/ ?>