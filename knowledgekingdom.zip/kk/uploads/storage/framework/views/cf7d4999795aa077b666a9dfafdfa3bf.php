<?php $__env->startSection('page_title', 'Slider'); ?>
<?php $__env->startSection('slider_page_active','active open'); ?>
<?php $__env->startSection('content'); ?>

          <!-- Content wrapper -->
          <div class="content-wrapper">
            <!-- Content -->

            <div class="container-xxl flex-grow-1 container-p-y">


              <!-- Basic Bootstrap Table -->


              <!-- Responsive Table -->
              <div class="card">
                <h5 class="card-header"> Sliders</h5>
                <?php if($message = Session::get('success')): ?>
                <div class="alert alert-success alert-block d-flex justify-content-between mx-2">
                    <strong><?php echo e($message); ?></strong>
                    
                    <a href="" type="button" class="close text-success" data-dismiss="alert"> X</a>
                </div>
                <?php endif; ?>
                <div class="table-responsive text-nowrap mx-3">
                  <table class="table " id="myDataTable">
                    <thead>
                      <tr class="text-nowrap">
                        <th>#</th>
                        <th>Title</th>
                        <th>Image</th>
						  <th>Slider Type</th>

                        <th>Status</th>
                        <th>Action</th>

                      </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $sliderdata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rows): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>

                        <th scope="row"><?php echo e($loop->index+1); ?></th>
                        <td><?php echo e($rows->title); ?></td>
                        <td><img src="<?php echo e(url('/storage/app/'.$rows->image)); ?>" class="rounded " width=100 height=100></td>
						<td><?php echo e($rows->slider_type); ?></td>

                        <td>  <div class="form-check form-switch mb-2">
                        <input class="form-check-input" type="checkbox" id="flexSwitchCheckDefault"  <?php if($rows->status == 1): ?> checked <?php endif; ?> onclick="updateStatus(<?php echo e($rows->id); ?>,<?php echo e($rows->status); ?>,'sliders','status')" />

                      </div></td>

                        <td><a href="<?php echo e(url('admin/edit/slider/'.$rows->id)); ?>" class="btn btn-info"><i class='bx bx-edit'></i></a>&nbsp;<a class="btn btn-danger" href="#" onclick= deleteRecord("<?php echo e(route('admin.delete.slider',$rows->id)); ?>")><i class='bx bx-message-square-x' ></i></a></td>
                      </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                  </table>
                </div>
              </div>
              <!--/ Responsive Table -->
            </div>
            <!-- / Content -->

          <?php $__env->stopSection(); ?>

<?php echo $__env->make('admin/layout/adminheaderfooter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/knowledgekingdom.in/httpdocs/resources/views/admin/slider/slider-table.blade.php ENDPATH**/ ?>