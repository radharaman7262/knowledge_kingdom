<?php echo e($slot); ?>

<?php /**PATH /var/www/vhosts/knowledgekingdom.in/httpdocs/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>