<?php $__env->startSection('page_title', 'Bussiness Setting'); ?>

<?php $__env->startSection('bussiness_active', 'active open'); ?>
<?php $__env->startSection('content'); ?>


    <!-- Content wrapper -->
    <div class="content-wrapper">
        <!-- Content -->

        <div class="container-xxl flex-grow-1 container-p-y">


            <!-- Basic Layout -->
            <div class="row">
                <div class="col-xl-12 col-md-12 mx-auto">
                    <div class="card mb-4">
                        <div class="card-header d-flex justify-content-center align-items-center">
                            <h5 class=" mb-0">Bussiness Setting</h5>
                            <!-- <small class="text-muted float-end">Default label</small> -->
                        </div>
                        <div class="card-body">
                            <form action="<?php echo e(route('admin.update-bussiness-setting')); ?>" method="POST"
                                enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="mb-3">
                                    <label class="form-label" for="basic-default-site-name">Site Name</label>
                                    <input type="text" name="site_name" value="<?php echo e($busssinss_setting->site_name); ?>"
                                        class="form-control" id="basic-default-site-name" placeholder="John Doe" />
                                </div>
                                <div class="row">

                                    <div class="col-6 mb-3">
                                        <label class="form-label" for="basic-default-favicon">Favicon</label>
                                        <img src="<?php echo e(url('storage/app/' . $busssinss_setting->favicon)); ?>" class="rounded ps-3 mb-2"
                                            alt="favicon" height="80px" width="100px">
                                        <input type="file" name="favicon" class="form-control" id="basic-default-favicon" />

                                    </div>
                                    <div class="col-6 mb-3">
                                        <label class="form-label" for="basic-default-logo">Logo</label>
                                        <img src="<?php echo e(url('storage/app/' . $busssinss_setting->logo)); ?>" class="rounded ps-3 mb-2"
                                            alt="logo" height="80px" width="100px">
                                        <input type="file" name="logo" class="form-control" id="basic-default-logo" />
                                    </div>
                                </div>
                                <div class="row">

                                    <div class="col-6 mb-3">
                                        <label class="form-label" for="basic-default-email-1">Email 1</label>
                                        <div class="input-group input-group-merge">
                                            <input type="email" name="email_1" value="<?php echo e($busssinss_setting->email_1); ?>"
                                                id="basic-default-email-1" class="form-control" placeholder="john.doe"
                                                aria-label="john.doe" aria-describedby="basic-default-email2" />
                                            <span class="input-group-text" id="basic-default-email2">@example.com</span>
                                        </div>
                                        <div class="form-text">You can use letters, numbers & periods</div>
                                    </div>
                                    <div class="col-6 mb-3">
                                        <label class="form-label" for="basic-default-email-2">Email 2</label>
                                        <div class="input-group input-group-merge">
                                            <input type="email" name="email_2" value="<?php echo e($busssinss_setting->email_2); ?>"
                                                id="basic-default-email-2" class="form-control" placeholder="john.doe"
                                                aria-label="john.doe" aria-describedby="basic-default-email2" />
                                            <span class="input-group-text" id="basic-default-email2">@example.com</span>
                                        </div>
                                        <div class="form-text">You can use letters, numbers & periods</div>
                                    </div>
                                </div>
                          
                               
								                          <div class="row">
                                    <div class="mb-3 col-6">
                                        <label class="form-label" for="basic-default-phone-1">Phone No 1</label>
                                        <input type="text" name="phone_1" pattern="[0-9]{10}" value="<?php echo e($busssinss_setting->phone_1); ?>"
                                            id="basic-default-phone-1" class="form-control phone-mask"
                                            placeholder="658 799 8941" />
                                    </div>

                                    <div class="mb-3 col-6">
                                        <label class="form-label" for="basic-default-phone-2">Phone No 2</label>
                                        <input type="text" name="phone_2" pattern="[0-9]{10}" value="<?php echo e($busssinss_setting->phone_2); ?>"
                                            id="basic-default-phone-2" class="form-control phone-mask"
                                            placeholder="658 799 8941" />
                                    </div>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label" for="basic-default-address">Address</label>
                                    <textarea id="basic-default-address" name="address" class="form-control"
                                        placeholder="Hi, Do you have a moment to talk Joe?"><?php echo e($busssinss_setting->address); ?></textarea>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label" for="basic-default-map">Map</label>
                                    <textarea id="basic-default-map" name="map" class="form-control"
                                        placeholder="Hi, Do you have a moment to talk Joe?"><?php echo e($busssinss_setting->map); ?></textarea>
                                </div>
                                <div class="row">
                                    <div class="col-6 mb-3">
                                        <label class="form-label" for="facebook">Facebook</label>
                                        <input type="text" name="facebook" value="<?php echo e($busssinss_setting->facebook); ?>"
                                            class="form-control" id="facebook" placeholder="www.facebook.com" />
                                    </div>
                                    <div class="col-6 mb-3">
                                        <label class="form-label" for="twitter">Twitter</label>
                                        <input type="text" name="twitter" value="<?php echo e($busssinss_setting->twitter); ?>"
                                            class="form-control" id="twitter" placeholder="www.twitter.com" />
                                    </div>
                                    <div class="col-6 mb-3">
                                        <label class="form-label" for="instagram">Instagram</label>
                                        <input type="text" name="instagram" value="<?php echo e($busssinss_setting->instagram); ?>"
                                            class="form-control" id="instagram" placeholder="www.instagram.com" />
                                    </div>
                                    <div class="col-6 mb-3">
                                        <label class="form-label" for="linkedin">LinkedIn</label>
                                        <input type="text" name="linkedin" value="<?php echo e($busssinss_setting->linkedin); ?>"
                                            class="form-control" id="linkedin" placeholder="www.linkedin.com" />
                                    </div>
                                </div>
								                         <div class="row">

                                    <div class="col-6 mb-3">
                                        <label class="form-label" for="basic-default-mail-email">Mail Email</label>
                                        <div class="input-group input-group-merge">
                                            <input type="email" name="mail_email" value="<?php echo e($busssinss_setting->mail_email); ?>"
                                                id="basic-default-mail-email" class="form-control" placeholder=""
                                                aria-label="john.doe" aria-describedby="basic-default-email2" />
                                            
                                        </div>

                                    </div>
                                    <div class="col-6 mb-3">
                                        <label class="form-label" for="password-field">Mail Password</label>
                                        <div class="input-group input-group-merge">
                                            <input type="text" name="mail_password" value="<?php echo e($busssinss_setting->mail_password); ?>"
                                                id="password-field" class="form-control pass-icon" placeholder=""
                                                aria-label="john.doe" aria-describedby="basic-default-email2" />

                                            </div>

                                    </div>
                                </div>
                                <div class="d-flex justify-content-center align-items-center">

                                    <input type="submit" name="submit" class="btn btn-primary " value="Save">
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <!-- #################### -->


            </div>
        </div>
        <!-- / Content -->
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.adminheaderfooter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/knowledgekingdom.in/httpdocs/resources/views/admin/bussiness-setting.blade.php ENDPATH**/ ?>