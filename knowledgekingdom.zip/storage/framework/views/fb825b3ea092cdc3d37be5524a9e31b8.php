<?php $__env->startSection('content'); ?>
        <!-- BEGIN: Hero Banner Start -->
        <section class="pageBanner" style="background-image: url(<?php echo e(asset('public/ui/assets/images/bg/banner.jpg')); ?>);">
            <div class="overlay"></div>
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <h2 class="bannerTitle">Our Country</h2>
                        <div class="breadcrumbs"><a href="index.html">Home</a><span>/</span>Country</div>
                    </div>
                </div>
            </div>
        </section>
        <!-- END: Hero Banner End -->

        <!-- BEGIN: Country Section Start -->
        <section class="countryPageSection">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12 text-center">
                        <h5 class="subTitle">Choose Country</h5>
                        <h2 class="secTitle">Immigration and citizenship Choose<br> your country <span class="typewrite" data-period="2000" data-type='[ "Australia", "Germany", "England", "Canada", "France", "Dubai", "Turkey", "India" ]'>Immigration</span><br></h2>
                    </div>
                </div>
                <div class="row">
                    <!-- Country Item -->
                    <?php $__currentLoopData = pagination_data('countries','8'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row_data_country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-3 col-sm-6">
                        <div class="countryItem02 ciItem02 text-center">
                            <div class="countryThumb">
                                <img src="<?php echo e(url('/storage/app/'.$row_data_country->image)); ?>" alt="<?php echo e($row_data_country->title); ?>" style="height: 250px;">
                                <div class="cnFlag"><img src="<?php echo e(url('/storage/app/'.$row_data_country->logo)); ?>" alt="<?php echo e($row_data_country->title); ?>"></div>
                            </div>
                            <div class="countryContent">
                                <h3><a href="<?php echo e(route('country-details-page',$row_data_country->slug)); ?>"><?php echo e($row_data_country->title); ?></a></h3>
                               
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <div class="">

                        <?php echo pagination_data('countries','8')->withQueryString()->links('pagination::bootstrap-5'); ?>

                    </div>

                </div>

            </div>
        </section>
        <!-- END: Country Section End -->

 <?php $__env->stopSection(); ?>

<?php echo $__env->make('ui.layout.headerfooter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/knowledgekingdom.in/httpdocs/resources/views/ui/country.blade.php ENDPATH**/ ?>