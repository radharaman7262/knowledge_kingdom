<?php $__env->startSection('page_title'); ?>
<?php echo e($country_data->meta_title); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('meta_descripation'); ?>
<?php echo e($country_data->meta_descripation); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('meta_keyword'); ?>
<?php echo e($country_data->meta_keyword); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

        <!-- BEGIN: Hero Banner Start -->
        <section class="pageBanner" style="background-image: url(<?php echo e(asset('public/ui/assets/images/bg/banner.jpg')); ?>);">
            <div class="overlay"></div>
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
						<h2 class="bannerTitle"> <?php echo e($country_data->title); ?></h2>
                        <div class="breadcrumbs"><a href="<?php echo e(route('/')); ?>">Home</a><span>/</span> Countries <span>/</span>   <?php echo e($country_data->title); ?></div>
                    </div>
                </div>
            </div>
        </section>
        <!-- END: Hero Banner End -->

        <!-- BEGIN: Service Details Start -->
        <section class="singleServiceSection">
            <div class="container">
                <div class="row">
                    <div class="col-lg-8">
                        <div class="serviceDConArea">

                            <div class="serviceDcon">
                                <h5 class="subTitle"><?php echo e($country_data->title); ?></h5>
                                <h3 class="secTitle">A WHOLE WORLD OF OPPORTUNITIES AWAITS YOU.</h3>
								
                                <p>
                                    <?php echo $country_data->description; ?>

                                </p>
                                <h5 class="subTitle">List of universities</h5>
                                <p><?php echo $country_data->universities; ?></p>




                            </div>

                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="row">
                            <div class="col-lg-12 col-sm-12"><img src="<?php echo e(url('/storage/app/'.$country_data->image)); ?>" alt="<?php echo e($country_data->title); ?>" style="height:400px;width:100%;"></div>
                            <div class="col-lg-12 col-sm-12">
                                <div class="sDcon">
                                    <h5 class="my-3 subTitle">Highlights</h5>

                                       <p><?php echo $country_data->hightlights; ?></p>

                                </div>
                            </div>
                        </div>

                    </div>


                </div>
            </div>
        </section>
        <!-- END: Service Details End -->

       <?php $__env->stopSection(); ?>

<?php echo $__env->make('ui.layout.headerfooter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/knowledgekingdom.in/httpdocs/resources/views/ui/country-detail.blade.php ENDPATH**/ ?>