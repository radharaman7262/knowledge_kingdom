<?php $__env->startSection('content'); ?>

        <!-- BEGIN: Hero Banner Start -->
        <section class="pageBanner" style="background-image: url(<?php echo e(asset('public/ui/assets/images/bg/banner.jpg')); ?>);">
            <div class="overlay"></div>
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <h2 class="bannerTitle">Result</h2>
                        <div class="breadcrumbs"><a href="<?php echo e(route('/')); ?>">Home</a><span>/</span>Result</div>
                    </div>
                </div>
            </div>
        </section>
        <!-- END: Hero Banner End -->

       <!-- BEGIN: About Section Start -->
    <section class="my-5">
        <div class="container">
            <div class="row">

                <div class="col-12">
                    <!-- About Content -->
                    <div class="aboutContent02 ">
                        <h4 class="subTitle mb-3">Results</h4>
                        
                        <p style="text-align: justify;">
                            <?php echo cms_setting_data('results_text'); ?>

                        </p>


                    </div>
                    <!-- About Content -->
                </div>
            </div>
        </div>
    </section>
    <!-- END: About Section End -->

       <?php $__env->stopSection(); ?>


<?php echo $__env->make('ui.layout.headerfooter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/knowledgekingdom.in/httpdocs/resources/views/ui/result.blade.php ENDPATH**/ ?>