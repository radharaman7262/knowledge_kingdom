<?php $__env->startSection('page_title', 'News Update'); ?>
<?php $__env->startSection('news_page_active','active open'); ?>
<?php $__env->startSection('content'); ?>

          <!-- Content wrapper -->
          <div class="content-wrapper">
            <!-- Content -->

            <div class="container-xxl flex-grow-1 container-p-y">


              <!-- Basic Bootstrap Table -->


              <!-- Responsive Table -->
              <div class="card">
                <h5 class="card-header">News Update</h5>
                <?php if($message = Session::get('success')): ?>
                <div class="alert alert-success alert-block d-flex justify-content-between mx-2">
                    <strong><?php echo e($message); ?></strong>
                    
                    <a href="" type="button" class="close text-success" data-dismiss="alert"> X</a>
                </div>
                <?php endif; ?>
                <div class="table-responsive text-nowrap mx-3">
                  <table class="table " id="myDataTable">
                    <thead>
                      <tr class="text-nowrap">
                        <th>#</th>
                        <th>Title</th>
                        <th>Date</th>
                        <th>Link</th>


                        <th>Status</th>
                        <th>Action</th>

                      </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $news_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rows): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>

                        <th scope="row"><?php echo e($loop->index+1); ?></th>
                        <td><?php echo e($rows->title); ?></td>
                        <td><?php echo e($rows->date); ?></td>
                        <td><?php echo e($rows->link); ?></td>



                        <td>  <div class="form-check form-switch mb-2">
                        <input class="form-check-input" type="checkbox" id="flexSwitchCheckDefault"  <?php if($rows->status == 1): ?> checked <?php endif; ?> onclick="updateStatus(<?php echo e($rows->id); ?>,<?php echo e($rows->status); ?>,'news_updates','status')" />

                      </div></td>

                        <td><a href="<?php echo e(url('admin/edit/news-update/'.$rows->id)); ?>" class="btn btn-info"><i class='bx bx-edit'></i></a>&nbsp;<a class="btn btn-danger" href="#" onclick= deleteRecord("<?php echo e(route('admin.delete.news-update',$rows->id)); ?>")><i class='bx bx-message-square-x' ></i></a></td>
                      </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                  </table>
                </div>
              </div>
              <!--/ Responsive Table -->
            </div>
            <!-- / Content -->

          <?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.adminheaderfooter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/knowledgekingdom.in/httpdocs/resources/views/admin/news-update/news-update-table.blade.php ENDPATH**/ ?>