<?php $__env->startSection('page_title', 'Contact'); ?>
<?php $__env->startSection('contact_page_active', 'active open'); ?>
<?php $__env->startSection('content'); ?>

    <!-- Content wrapper -->
    <div class="content-wrapper">
        <!-- Content -->

        <div class="container-xxl flex-grow-1 container-p-y">


            <!-- Basic Bootstrap Table -->


            <!-- Responsive Table -->
            <div class="card">
                <h5 class="card-header">Contact</h5>
                <?php if($message = Session::get('success')): ?>
                    <div class="alert alert-success alert-block d-flex justify-content-between">
                        <strong><?php echo e($message); ?></strong>
                        
                        <a href="" type="button" class="close text-success" data-dismiss="alert"> X</a>
                    </div>
                <?php endif; ?>
                <div class="table-responsive text-nowrap mx-3">
                    <table class="table " id="myDataTable">
                        <thead>
                            <tr class="text-nowrap">
                                <th>#</th>
                                <th>Name</th>
                                <th>Phone</th>
                                <th>Email</th>
                                <th>Subject</th>
                                <th>Message</th>
                                <th>Date & Time</th>
                                <th>Status</th>



                                <th>Action</th>

                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rows): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>

                                    <th scope="row"><?php echo e($loop->index + 1); ?></th>
                                    <td><?php echo e($rows->name); ?></td>
                                    <td><?php echo e($rows->phone); ?></td>
                                    <td><?php echo e($rows->email); ?></td>
                                    <td><?php echo $rows->subject; ?></td>
                                    <td><?php echo $rows->message; ?></td>
                                    <td><?php echo e($rows->created_at); ?></td>
                                    <td><?php if ($rows->status == 0) {
                                        echo "<p class='badge bg-info text-light'>Unseen</p>";
                                    } else {
                                        echo "<p class='badge bg-success text-light'>Seen</p>";
                                    } ?></td>


                                    <td>
                                        <?php if ($rows->status == 1) { ?>

                                        <a href="#" class="btn btn-danger badge"
                                            onclick=deleteRecord("<?php echo e(route('admin.delete.faq-category', $rows->id)); ?>")><i
                                                class="fas fa-trash-alt"></i> Delete</a>


                                        <?php
    } else { ?>

                                        <a href="#" id="id-approve"
                                            onclick="approveFunction(<?= $rows->id ?>,<?= $rows->status ?>)"
                                            class="btn btn-success badge"><i class="fas fa-edit"></i>&nbsp;Seen</a>


                                        <a href="#" class="btn btn-danger badge"
                                            onclick=deleteRecord("<?php echo e(route('admin.delete.faq-category', $rows->id)); ?>")><i
                                                class="fas fa-trash-alt"></i> Delete</a>
                                        <?php
    }
    ?>

                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>
                </div>
            </div>
            <!--/ Responsive Table -->


            <!-- delete model -->
            <div class="modal fade" id="confirm" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
                aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header ">
                            <h4 class="modal-title text-start" id="myModalLabel">Delete
                                Confirmation</h4>
                            

                        </div>
                        <div class="modal-body">
                            <p>Are you sure want to delete this item?</p>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                            <a id="delete_row" class="btn btn-danger btn-ok">Delete</a>
                        </div>
                    </div>
                </div>
            </div>



        </div>
        <!-- / Content -->

    <?php $__env->stopSection(); ?>

    <script>
        function deleteRecord(id) {


            $("#delete_row").attr("href", id);
            $("#confirm").modal("show");
        }
    </script>

<script>
    function approveFunction(id,status) {

        $.ajax({

            url: "<?php echo e(route('admin.contact.ajax')); ?>",
            method: "POST",
            data: {
                cont_id: id,
                cont_status: status,
                _token: "<?php echo e(csrf_token()); ?>",
            },
            success: function(responce) {
                if (responce == 1) {
                    alert("seen");
                    location.reload();
                        } else {
                            location.reload();
                        }

            }
        });

    }
</script>

<?php echo $__env->make('admin.layout.adminheaderfooter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/knowledgekingdom.in/httpdocs/resources/views/admin/contact/contact-table.blade.php ENDPATH**/ ?>