<?php $__env->startSection('page_title'); ?>
<?php echo e($coaching_data->meta_title); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('meta_descripation'); ?>
<?php echo e($coaching_data->meta_descripation); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('meta_keyword'); ?>
<?php echo e($coaching_data->meta_keyword); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

        <!-- BEGIN: Hero Banner Start -->
        <section class="pageBanner" style="background-image: url(<?php echo e(asset('public/ui/assets/images/bg/banner.jpg')); ?>);">
            <div class="overlay"></div>
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <h2 class="bannerTitle">Study In <?php echo e($coaching_data->title); ?></h2>
                        <div class="breadcrumbs"><a href="<?php echo e(route('/')); ?>">Home</a><span>/</span>Coaching<span>/</span><?php echo e($coaching_data->title); ?></div>
                    </div>
                </div>
            </div>
        </section>
        <!-- END: Hero Banner End -->

        <!-- BEGIN: Service Details Start -->
        <section class="singleServiceSection">
            <div class="container">
                <div class="row">
                    <div class="col-lg-8">
                        <div class="serviceDConArea">

                            <div class="serviceDcon">
                                <h5 class="subTitle"><?php echo e($coaching_data->title); ?></h5>
                                
                                <p>
                                    <?php echo $coaching_data->short_desc; ?>

                                </p>
                                <h5 class="subTitle">Exam details</h5>
                                <p><?php echo $coaching_data->exam_detail; ?></p>




                            </div>

                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="row">
                            <div class="col-lg-12 col-sm-12"><img src="<?php echo e(url('/storage/app/'.$coaching_data->image)); ?>" alt="<?php echo e($coaching_data->title); ?>" style="height:200px;"></div>
                            <div class="col-lg-12 col-sm-12">
                                <div class="sDcon">
                                    <h5 class="my-3 subTitle">Highlights</h5>

                                       <p><?php echo $coaching_data->hightlights; ?></p>

                                </div>
                            </div>
                        </div>

                    </div>


                </div>
            </div>
        </section>
        <!-- END: Service Details End -->

       <?php $__env->stopSection(); ?>

<?php echo $__env->make('ui.layout.headerfooter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/knowledgekingdom.in/httpdocs/resources/views/ui/coaching-detail.blade.php ENDPATH**/ ?>