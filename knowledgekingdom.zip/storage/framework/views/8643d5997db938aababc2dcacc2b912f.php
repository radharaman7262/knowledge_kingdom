<?php
    $page_name = seo_data("page_name","6");
    $meta_title = seo_data("meta_title","6");
    $meta_descripation = seo_data("meta_descripation","6");
    $meta_keyword = seo_data("meta_keyword","6");
?>
<?php $__env->startSection('page_title',$page_name); ?>
<?php $__env->startSection('meta_title',$meta_title); ?>
<?php $__env->startSection('meta_descripation',$meta_descripation); ?>
<?php $__env->startSection('meta_keyword',$meta_keyword); ?>
<?php $__env->startSection('content'); ?>

        <!-- BEGIN: Hero Banner Start -->
        <section class="pageBanner" style="background-image: url(<?php echo e(asset('public/ui/assets/images/bg/banner.jpg')); ?>);">
            <div class="overlay"></div>
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <h2 class="bannerTitle">Achievers</h2>
                        <div class="breadcrumbs"><a href="<?php echo e(url('/')); ?>">Home</a><span>/</span>Achievers</div>
                    </div>
                </div>
            </div>
        </section>
        <!-- END: Hero Banner End -->



        <!-- BEGIN: Team Section Start -->
        <section class="teamSection01">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12 text-center">
                        <h5 class="subTitle">Professional People</h5>
                        <h2 class="secTitle">Meet Our Expert Visa<br> Consultants</h2>
                    </div>
                </div>
                <div class="row">
                    <?php $__currentLoopData = pagination_data('achievers','8'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row_data_achievers): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <div class="col-lg-3 col-sm-6 mb-4">
                        <!-- Team Item -->
                        <div class="teamItem01">
                            <div class="teamThumb">
                                <img src="<?php echo e(url('/storage/app/'.$row_data_achievers->image)); ?>" alt="<?php echo e($row_data_achievers->name); ?>">

                            </div>
                            <div class="teamContent">
                                <h3><a href="single-team.html"><?php echo e($row_data_achievers->name); ?></a></h3>
                                <h5 class="designation"><?php echo e($row_data_achievers->address); ?></h5>
                            </div>
                        </div>
                        <!-- Team Item -->
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <div class="">

                        <?php echo pagination_data('achievers','8')->withQueryString()->links('pagination::bootstrap-5'); ?>

                    </div>

                </div>
            </div>
        </section>
        <!-- END: Team Section End -->


   <?php $__env->stopSection(); ?>


<?php echo $__env->make('ui.layout.headerfooter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/knowledgekingdom.in/httpdocs/resources/views/ui/achivers.blade.php ENDPATH**/ ?>